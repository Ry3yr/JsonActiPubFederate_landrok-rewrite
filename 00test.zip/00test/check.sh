sudo bash -c '
echo "=== Check if rewrite_module is enabled ==="
apache2ctl -M | grep rewrite

echo -e "\n=== Check AllowOverride in sites-enabled ==="
grep -Ri AllowOverride /etc/apache2/sites-enabled/

echo -e "\n=== Check if .htaccess exists and permissions ==="
if [ -f /var/www/html/.htaccess ]; then
  ls -l /var/www/html/.htaccess
else
  echo ".htaccess not found in /var/www/html"
fi

echo -e "\n=== Tail last 20 lines of Apache error log ==="
tail -n 20 /var/log/apache2/error.log
'
